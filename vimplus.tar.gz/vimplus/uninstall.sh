#!/bin/bash

sudo rm -rf ~/.vimrc
sudo rm -rf ~/.vim

echo "Done!"

